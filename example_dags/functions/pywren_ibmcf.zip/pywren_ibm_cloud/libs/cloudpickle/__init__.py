import pickle


from pywren_ibm_cloud.libs.cloudpickle.cloudpickle import *


__version__ = '1.2.2'
