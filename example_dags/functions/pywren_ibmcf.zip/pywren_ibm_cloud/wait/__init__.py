from pywren_ibm_cloud.wait.wait_storage import wait_storage
from pywren_ibm_cloud.wait.wait_rabbitmq import wait_rabbitmq

ALL_COMPLETED = 1
ANY_COMPLETED = 2
ALWAYS = 3
