def load_config(config_data):
    pass
